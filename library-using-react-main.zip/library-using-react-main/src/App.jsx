import { useState } from "react";
import LoginPage from "./components/LoginPage";
import RegisterPage from "./components/RegisterPage";
import HomePage from "./components/HomePage";
import WebPage from "./components/WebPage";
import "./style.css";

export default function App() {
  const [currentPage, setCurrentPage] = useState("loginPage");

  const showPage = (page) => setCurrentPage(page);

  return (
    <>
      {currentPage === "loginPage" && <LoginPage showPage={showPage} />}
      {currentPage === "registerPage" && <RegisterPage showPage={showPage} />}
      {currentPage === "homePage" && <HomePage showPage={showPage} />}
      {currentPage === "webpage" && <WebPage showPage={showPage} />}
    </>
  );
}
