import BookCarousel from "./BookCarousel";

export default function WebPage() {
  return (
    <div className="webpage">
      <header>
        <h1 className="logo">
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2N49mgVGM4hkBJclxFJaWrHTLokFcbPCqOQ&s"
            alt="Logo"
            className="logo-image"
          />
          READICTION
        </h1>
        <div className="search-container">
          <input type="text" placeholder="Search books..." className="search-input" />
          <button className="search-button">🔍</button>
        </div>
        <nav>
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="books.html">Books</a></li>
            <li><a href="gen.html">Genres</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
            <li><a href="settings.html">Settings</a></li>
          </ul>
        </nav>
      </header>

      <div className="webpage-bottom">
        <section>
          <h2>New Arrivals</h2>
          <BookCarousel />
        </section>
      </div>
    </div>
  );
}
