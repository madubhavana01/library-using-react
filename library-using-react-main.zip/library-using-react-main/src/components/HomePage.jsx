export default function HomePage({ showPage }) {
  return (
    <div className="homepage">
      <img src="https://cdn-icons-png.flaticon.com/512/29/29302.png" alt="Library Logo" />
      <h1>Welcome to the Book Library</h1>
      <p>
        Explore a world of books across genres, authors, and topics. Find your next favorite read!
      </p>
      <button className="btn" onClick={() => showPage("webpage")}>
        Browse Books
      </button>
    </div>
  );
}
