export default function BookCarousel() {
  const books = [
    "https://images-na.ssl-images-amazon.com/images/I/81-QB7nDh4L.jpg",
    "https://images-na.ssl-images-amazon.com/images/I/91uwocAMtSL.jpg",
    "https://images-na.ssl-images-amazon.com/images/I/81gepf1eMqL.jpg",
    "https://images-na.ssl-images-amazon.com/images/I/81YOuOGFCJL.jpg",
    "https://images-na.ssl-images-amazon.com/images/I/71aFt4+OTOL.jpg",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaITjsDlb1Z2QfRvL4Tojjs7ieBB_IvzUsFA&s",
    "https://res.cloudinary.com/hzpwrwfdi/image/upload/w_220/media/covers/712DAFX4V7L_prebf2",
    "https://cdn.penguin.co.in/wp-content/uploads/2022/02/9780143454458.jpg",
    "https://m.media-amazon.com/images/I/71xoOPLEHxL._UF1000,1000_QL80_.jpg",
    "https://cdn.testbook.com/1695642679794-Mahatma%20Gandhi%20Autobiography%20-%20The%20Story%20Of%20My%20Experiments%20With%20Truth.jpg/1695642681.jpeg",
  ];

  return (
    <div className="book-carousel">
      {books.map((src, index) => (
        <img key={index} src={src} alt={`Book ${index + 1}`} />
      ))}
    </div>
  );
}
