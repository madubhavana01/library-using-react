import React from "react";

export default function LoginPage({ showPage }) {
  const handleLogin = (e) => {
    e.preventDefault();
    // Normally you’d verify credentials here
    showPage("homePage");
  };

  return (
    <div className="container">
      <form onSubmit={handleLogin}>
        <h2>📚 READICTION Login</h2>

        <input type="email" placeholder="Email" required />
        <input type="password" placeholder="Password" required />

        <button type="submit">Login</button>

        <p>
          Don&apos;t have an account?{" "}
          <a onClick={() => showPage("registerPage")}>Register</a>
        </p>
      </form>
    </div>
  );
}
