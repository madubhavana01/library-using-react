import React from "react";

export default function RegisterPage({ showPage }) {
  const handleRegister = (e) => {
    e.preventDefault();
    // Normally you’d create the account here
    // After successful registration, go back to the login page
    showPage("loginPage");
  };

  return (
    <div className="container">
      <form onSubmit={handleRegister}>
        <h2>📚 READICTION</h2>

        <input type="text" placeholder="Full Name" required />
        <input type="email" placeholder="Email Address" required />
        <input type="password" placeholder="Password" required />
        <input type="password" placeholder="Confirm Password" required />
        <input type="tel" placeholder="Phone Number (optional)" />

        <select required>
          <option value="">Select User Type</option>
          <option value="user">USER</option>
          <option value="admin">ADMIN</option>
        </select>

        <button type="submit">Register</button>

        <p>
          Already have an account?{" "}
          <a onClick={() => showPage("loginPage")}>Login</a>
        </p>
      </form>
    </div>
  );
}
